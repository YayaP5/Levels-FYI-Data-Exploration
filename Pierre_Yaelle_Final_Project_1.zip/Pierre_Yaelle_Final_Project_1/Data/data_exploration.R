# load libraries -----
library(tidyverse)
library(readr)
library(skimr)
library(stringr)
library(dbplyr)

# read data -----
data_jobs_cleaned <- read_csv("Processed/data_jobs_cleaned.csv")


#Totalyearlycompensation ----
data_jobs_cleaned %>% 
  skim_without_charts(totalyearlycompensation)

# Title -----

data_jobs_cleaned %>% 
  skim_without_charts(title)

## count jobs 
job_types <- data_jobs_cleaned %>%
  group_by(title) %>%
  arrange(title) %>%
  count(sort = TRUE)

print(job_types)

data_jobs_cleaned %>% 
  group_by(title) %>%
  skim_without_charts(totalyearlycompensation) 

## title vs pay
ggplot(data = data_jobs_cleaned, mapping = aes(x = title, y = totalyearlycompensation)) + 
  geom_boxplot() +
  ylim(c(0,400000)) +
  coord_flip() 

# Gender -----

# does gender impact pay? 
gender <- data_jobs_cleaned %>%
  group_by(gender) %>%
  arrange(gender) %>%
  count(sort = TRUE)

#univariable gender
gender <- data_jobs_cleaned %>%
  filter(gender == 'male' | gender == 'female')


gender_bar<- ggplot(gender, aes(x="", y=value, fill=group))+
  geom_bar(width = 1, stat = "identity")
bp


ggplot(data = gender, mapping = aes(x = title, y = totalyearlycompensation)) + 
  geom_boxplot(aes(fill = gender)) +
  ylim(c(0,400000)) +
  coord_flip()
  
ggplot(data = gender, mapping = aes(x = Education, y = totalyearlycompensation)) + 
  geom_boxplot(aes(fill = gender)) +
  ylim(c(0,400000)) +
  coord_flip() 
               
               
# Education ----
scientist_engineer <- data_jobs_cleaned %>%
  filter(title = c('software engineer' , 'data scientist', 'mechanical engineer', 'hardware engineer'))

ggplot(data = scientist_engineer, mapping = aes(x = title, y = totalyearlycompensation)) + 
  geom_boxplot(aes(fill = Education)) +
  ylim(c(0,400000)) +
  coord_flip() 



# Company ----

# software engineering
companies_software <- data_jobs_cleaned %>%
  filter(title == "software engineer") %>%
  count(company, sort = TRUE) %>%
  head(30)

companies_software <- companies_software$company

plot_software <- data_jobs_cleaned %>%
  filter(title == "software engineer") %>%
  filter(company %in% companies_software) %>%
  group_by(company) %>%
  summarise(mean_comp = mean(totalyearlycompensation)) 

  ggplot(plot_software) +
  geom_col(mapping = aes(x = reorder(company, mean_comp), y= mean_comp)) +
  coord_flip()

#data_science  
  companies_data_science <- data_jobs_cleaned %>%
    filter(title == "data scientist") %>%
    count(company, sort = TRUE) %>%
    head(30)
  
  companies_data_science <- companies_data_science$company
  
  plot_data_science <- data_jobs_cleaned %>%
    filter(title == "data scientist") %>%
    filter(company %in% companies_data_science) %>%
    group_by(company) %>%
    summarise(mean_comp = mean(totalyearlycompensation)) 
  
  ggplot(plot_data_science) +
    geom_col(mapping = aes(x = reorder(company, mean_comp), y= mean_comp)) +
    coord_flip()
  
# Race ----

#years at company vs race 
scientist_engineer %>%
    filter(!is.na(Race)) %>%
  ggplot() + 
    geom_bar(aes(x = Race, fill = title)) +
    coord_flip()
    
  
ggplot(data = gender) + 
  geom_histogram(aes(x = yearsatcompany)) + 
  ylim(c(0,70)) +
  facet_wrap(Race ~ gender)

  
ggplot(data = gender) + 
  geom_point(aes(x = yearsatcompany, y = totalyearlycompensation)) + 
  ylim(c(0,400000)) +
  facet_wrap(~Race)
